from NeuralNetwork.torch_cnn.mel import MEL_CNN
from NeuralNetwork.torch_cnn.chr import CHR_CNN

__all__ = ["MEL_CNN", "CHR_CNN"]